CREATE TABLE `london_attractions_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `place_id` int(11) NOT NULL,
  `sub_category` varchar(64) NOT NULL,
  `lat` decimal(16,14) NOT NULL,
  `lng` decimal(16,14) NOT NULL,
  `ben_lat_dis` decimal(16,14) NOT NULL,
  `ben_lng_dis` decimal(16,14) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ben_lat_dis` (`ben_lat_dis`),
  KEY `ben_lng_dis` (`ben_lng_dis`),
  KEY `place_id` (`place_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;