import pymysql
from pymongo import MongoClient

connection_data = {
    "host": "112.74.167.102",
    "user": "vvmint",
    "db": "dev",
    "port": 3306,
    "password": "aptx4869+-.",
    "charset": "utf8"
}

conn = pymysql.connect(**connection_data)

client = MongoClient("13.58.196.58", 27017)
db = client.test
db.authenticate("lichangx", "Password@950610")


def upload_place():
    results = []
    accommodations = db.london_accommodations
    for index, element in enumerate(accommodations.find()):
        data = {
            "place_id": element["id"],
            "details": element["details"],
            "reviews": element["reviews"],
            "classify": "accommodation",
            "sub_category": element["subCategory"]
        }
        results.append(data)
        if len(results) == 200:
            with conn.cursor() as cursor:
                cursor.executemany(
                    """
                      insert into london_place (place_id, details, reviews, 
                      classify, sub_category) values (%s, %s, %s, %s, %s)
                    """, [(d["place_id"], d["details"], d["reviews"], d["classify"], d["sub_category"]) for d in results])
                conn.commit()
                print("two hundred finish")
                results = []
        print("now index: "+ str(index))
    if len(results) > 0:
        with conn.cursor() as cursor:
            cursor.executemany(
                """
                  insert into london_place (place_id, details, reviews, 
                  classify, sub_category) values (%s, %s, %s, %s, %s)
                """, [(d["place_id"], d["details"], d["reviews"], d["classify"], d["sub_category"]) for d in results])
            conn.commit()
    return "ok"


def upload_reviews():
    results = []
    reviews = db.london_reviews
    for index, element in enumerate(reviews.find()):
        if element.get("reviews") and len(element["reviews"]) > 0:
            for x in element["reviews"]:
                data = {
                    "language": x["language"],
                    "polarity": x["polarity"] if x.get("polarity") else 0,
                    "rating": x["rating"] if x["rating"] else 0,
                    "source": x["source"],
                    "time": x["time"],
                    "words_count": x["wordsCount"],
                    "details": x["details"],
                    "place_id": element["placeId"]
                }
                results.append(data)
        if len(results) >= 200:
            with conn.cursor() as cursor:
                cursor.executemany("""
                    insert into london_accommodations_reviews (language, polarity, rating, source, time, words_count, details, place_id)
                    values (%s, %s, %s, %s, %s, %s, %s, %s)
                """, [(d["language"], d["polarity"], d["rating"], d["source"], d["time"], d["words_count"], d["details"], d["place_id"]) for d in results])
                conn.commit()
                results = []
                print("two hunderd finish")
        print("now index:" + str(index))
    if len(results) > 0:
        with conn.cursor() as cursor:
            cursor.executemany("""
                insert into london_accommodations_reviews (language, polarity, rating, source, time, words_count, details, place_id)
                values (%s, %s, %s, %s, %s, %s, %s, %s)
            """, [(d["language"], d["polarity"], d["rating"], d["source"], d["time"], d["words_count"], d["details"], d["place_id"]) for d in results])
            conn.commit()
    return "ok"


def upload_details():
    results = []
    details = db.london_attractions_details
    for index, element in enumerate(details.find()):
        data = {
            "place_id": element["id"],
            "sub_category": element["subCategory"],
            "lat": element["lat"],
            "lng": element["lng"],
            "ben_lat_dis": element["ben_lat_dis"],
            "ben_lng_dis": element["ben_lng_dis"]
        }
        results.append(data)
        if len(results) == 200:
            with conn.cursor() as cursor:
                cursor.executemany("""
                    insert into london_attractions_details(place_id, sub_category, lat, lng, ben_lat_dis, ben_lng_dis)
                    values (%s, %s, %s, %s, %s, %s)
                """, [(d["place_id"], d["sub_category"], d["lat"], d["lng"], d["ben_lat_dis"], d["ben_lng_dis"]) for d in results])
            conn.commit()
            print("two hundred finish")
        print("now index: " + str(index))
    if len(results) > 0:
        with conn.cursor() as cursor:
            cursor.executemany("""
                insert into london_attractions_details(place_id, sub_category, lat, lng, ben_lat_dis, ben_lng_dis)
                values (%s, %s, %s, %s, %s, %s)
            """, [(d["place_id"], d["sub_category"], d["lat"], d["lng"], d["ben_lat_dis"], d["ben_lng_dis"]) for d in
                  results])
        conn.commit()
    return "ok"

if __name__ == "__main__":
    print(upload_details())
