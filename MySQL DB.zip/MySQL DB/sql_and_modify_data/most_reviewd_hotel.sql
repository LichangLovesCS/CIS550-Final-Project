select london_place.place_id, A.count
from london_place
    join (select place_id, count(place_id) as count
    from london_accommodations_reviews
    GROUP BY place_id
    ORDER BY count DESC limit 1)
    AS A 
where A.place_id = london_place.place_id;

