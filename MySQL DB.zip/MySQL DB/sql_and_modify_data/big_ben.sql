select 
  london_place.place_id, london_place.details, 
  A.ben_lat_dis, A.ben_lng_dis 
from london_place
  JOIN (
         SELECT place_id, ben_lng_dis, ben_lat_dis 
         from london_attractions_details 
         ORDER BY ben_lat_dis, ben_lng_dis DESC LIMIT 5) as A
where A.place_id = london_place.place_id;



