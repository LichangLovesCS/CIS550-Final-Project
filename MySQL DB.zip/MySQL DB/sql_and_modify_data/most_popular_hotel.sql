select london_place.place_id, A.count
from london_place join (
  select B.place_id, count(B.language) as count
    from (
    select DISTINCT place_id, language
        from london_accommodations_reviews
  ) as B
    GROUP BY B.place_id
    ORDER BY count DESC LIMIT 10) as A
where A.place_id = london_place.place_id;