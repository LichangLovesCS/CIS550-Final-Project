create table london_place (
  id int PRIMARY KEY AUTO_INCREMENT,
  place_id INTEGER  NOT NULL ,
  details TEXT NOT NULL ,
  reviews TEXT NOT NULL ,
  classify varchar(64) NOT NULL ,
  sub_category VARCHAR(64) NOT NULL ,
  KEY (classify),
  KEY (sub_category),
  KEY (place_id)
);