select DISTINCT london_place.place_id, london_place.details
from london_place
    join london_attractions_reviews USING (place_id)
where polarity = 10 AND rating = 5
LIMIT 10;