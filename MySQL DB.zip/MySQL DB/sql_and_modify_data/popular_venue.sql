select
if((A.count - B.count > 0 and A.count - C.count > 0), A.place_id,
if((B.count - C.count > 0 and B.count - A.count > 0), B.place_id, C.place_id)) as place from
(SELECT place_id, count(london_accommodations_reviews.place_id) as count
from london_accommodations_reviews
GROUP BY place_id
ORDER BY count DESC LIMIT 1) as A
,
(SELECT place_id, count(london_attractions_reviews.place_id) as count
FROM london_attractions_reviews
GROUP BY place_id
ORDER BY count DESC LIMIT 1) as B
,
(SELECT place_id, count(london_restaurants_reviews.place_id) as count
from london_restaurants_reviews
GROUP BY place_id
ORDER BY count DESC LIMIT 1) as C;