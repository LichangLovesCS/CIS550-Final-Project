select london_place.place_id, A.pol
from london_place join (
  SELECT place_id, avg(polarity) as pol
    from london_restaurants_reviews
    where polarity > 0
    GROUP BY place_id
    ORDER BY pol desc LIMIT 10
  ) as A
where A.place_id = london_place.place_id ;