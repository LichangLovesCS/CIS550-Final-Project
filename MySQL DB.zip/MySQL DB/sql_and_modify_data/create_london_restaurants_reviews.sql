CREATE TABLE `london_restaurants_reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(16) NOT NULL,
  `polarity` tinyint(4) NOT NULL,
  `rating` tinyint(4) NOT NULL,
  `source` varchar(32) NOT NULL,
  `time` datetime NOT NULL,
  `words_count` int(11) NOT NULL,
  `details` text NOT NULL,
  `place_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `language` (`language`),
  KEY `words_count` (`words_count`),
  KEY `place_id` (`place_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8