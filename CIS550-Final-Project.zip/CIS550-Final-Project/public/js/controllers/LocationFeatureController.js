angular.module('LocationFeatureController', [])

	.controller('mainController', ['$scope','$http','LocationFeatures', function($scope, $http, LocationFeatures) {

				
	}]);