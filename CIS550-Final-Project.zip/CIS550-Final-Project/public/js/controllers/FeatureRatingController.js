angular.module('FeatureRatingController', [])

	.controller('mainController', ['$scope','$http','FeatureRatings', function($scope, $http, FeatureRatings) {

				
	}]);