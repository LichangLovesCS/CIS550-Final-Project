const mongoose = require('mongoose')

exports.attractionsReviewsUpdates = mongoose.model('london_attractions_reviews_calculates', new mongoose.Schema({
}), 'london_attractions_reviews_calculates', true)

exports.attractionsDetails = mongoose.model('london_attractions_details', new mongoose.Schema({
}), 'london_attractions_details', true)

exports.attractionsReviews = mongoose.model('london_attractions_reviews', new mongoose.Schema({
  reviews: String,
  placeId: Number
}), 'london_attractions_reviews', true)