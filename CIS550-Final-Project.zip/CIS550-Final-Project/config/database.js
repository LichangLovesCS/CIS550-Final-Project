module.exports = {
    remoteUrl: 'mongodb://lichangx:Password%40950610@13.58.196.58:27017/test',
    localUrl: 'mongodb://localhost:27017'
};
